package cz.osu.KU1;

import cz.osu.Cv02_Line;
import cz.osu.V_RAM;

import java.awt.*;
import java.util.ArrayList;

public class KU1_BezierAsMSWord {
    public static void drawBezier(V_RAM v_ram, Point p0, Point p1, Point p2, Point p3, int red, int green, int blue,int steps){

        ArrayList<Point>points=new ArrayList<>();
        double d=1.0/steps;

        int qx0=p0.x;
        int qx1=3*(p1.x-p0.x);
        int qx2=3*(p2.x-2*p1.x+p0.x);
        int qx3=p3.x-3*p2.x+3*p1.x-p0.x;
        int qy0=p0.y;
        int qy1=3*(p1.y-p0.y);
        int qy2=3*(p2.y-2*p1.y+p0.y);
        int qy3=p3.y-3*p2.y+3*p1.y-p0.y;
        for (double t = d; t <1; t=t+d) {
            double tt=t*t;
            double ttt=tt*t;
            Point point = new Point((int)(qx0 + qx1*t + qx2*tt + qx3*ttt),(int)(qy0 + qy1*t + qy2*tt + qy3*tt));
            points.add(point);
        }
        Cv02_Line.drawLine(v_ram, p0.x, p0.y,points.get(0).x, points.get(0).y,red,green,blue);
        for (int i = 0; i < points.size()-1; i++) {
            Cv02_Line.drawLine(v_ram, points.get(i).x, points.get(i).y,points.get(i+1).x, points.get(i+1).y,red,green,blue);
        }
    }
}
