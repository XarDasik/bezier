package cz.osu;

import java.awt.*;

public class Cv02_Line {

    public static void drawLine(V_RAM v_ram, int x1, int y1, int x2, int y2, int red, int green, int blue){

        Point pz = new Point(x1, y1);
        Point pk = new Point(x2, y2);

        int dx = pk.x - pz.x;
        int dy = pk.y - pz.y;

        if (pz.x == pk.x && pz.y == pk.y) {
            v_ram.setPixel(pz.x, pz.y, red, green, blue);
            return;
        } else if (dx == 0){
            //svisla usecka
            int x;
            if(pz.y > pk.y) switchPoints(pz, pk);
            float b = (pk.y*pz.x-pz.y*pk.x) / (float)(pk.y - pz.y);
            for (int y = pz.y; y <= pk.y; y++) {
                x = Math.round(b);
                v_ram.setPixel(x,y,red, green, blue);
            }
            return;
        } else if (dy == 0){
            //vodorovna usecka
            int y;
            if(pz.x > pk.x) switchPoints(pz, pk);
            float b = (pk.x*pz.y-pz.x*pk.y) / (float)(pk.x - pz.x);
            for (int x = pz.x; x <= pk.x; x++) {
                y = Math.round(b);
                v_ram.setPixel(x,y,red, green, blue);
            }
            return;
    }
        if(Math.abs(dx) > Math.abs(dy)){
            if(pz.x > pk.x) switchPoints(pz, pk);
            bresenhamLow(pz, pk, v_ram, red, green, blue);
        } else {
            if(pz.y > pk.y) switchPoints(pz, pk);
            bresenhamHigh(pz,pk, v_ram, red, green, blue);
        }
    }

    private static void bresenhamLow(Point pz, Point pk, V_RAM vram, int red, int green, int blue) {
        int d;
        int h;
        int h1;
        int h2;
        if (pz.y > pk.y){
            d=-1;
        } else d = 1;
        h1 = 2*Math.abs(pk.y - pz.y);
        h2 = h1 - 2 * (pk.x - pz.x);
        h = h1 - (pk.x - pz.x);
        for (int x = pz.x; x <= pk.x; x++) {
            vram.setPixel(x, pz.y, red, green, blue);
            if (h > 0){
                pz.y += d;
                h += h2;
            } else h += h1;
        }
        vram.setPixel(pk.x, pk.y, red, green, blue);
    }

    private static void bresenhamHigh(Point pz, Point pk, V_RAM vram, int red, int green, int blue) {
        int d;
        int h;
        int h1;
        int h2;
        if (pz.x > pk.x){
            d=-1;
        } else d = 1;
        h1 = 2*Math.abs(pk.x - pz.x);
        h2 = h1 - 2 * (pk.y - pz.y);
        h = h1 - (pk.y - pz.y);
        for (int y = pz.y; y <= pk.y; y++) {
            vram.setPixel(pz.x, y, red, green, blue);
            if (h > 0){
                pz.x += d;
                h += h2;
            } else h += h1;
        }
        vram.setPixel(pk.x, pk.y, red, green, blue);
    }

    private static void switchPoints(Point pz, Point pk) {
        int x = pz.x;
        int y = pz.y;

        pz.x = pk.x;
        pz.y = pk.y;

        pk.x = x;
        pk.y = y;
    }

    public static void insertPointFromLineToMinMax(MinMaxInX[] data, Point pz, Point pk, int minY){
        int d;
        int h;
        int h1;
        int h2;
        if (pz.y > pk.y){
            d=-1;
        } else d = 1;
        h1 = 2*Math.abs(pk.y - pz.y);
        h2 = h1 - 2 * (pk.x - pz.x);
        h = h1 - (pk.x - pz.x);
        for (int x = pz.x; x <= pk.x; x++) {
            //data[y - minY].minX = Math.min(data[y - minY].minX, x); //toto patří za DDA while(true){
            //data[y - minY].maxX = Math.max(data[y - minY].maxX, x);
            //vram.setPixel(x, pz.y, red, green, blue);
            if (h > 0){
                pz.y += d;
                h += h2;
            } else h += h1;
        }


    }
}