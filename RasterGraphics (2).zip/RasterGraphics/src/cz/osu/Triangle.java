package cz.osu;

import java.awt.*;

public class Triangle {
    public int iPA;
    public int iPB;
    public int iPC;

    public Triangle(int iPA, int iPB, int iPC) {
        this.iPA = iPA;
        this.iPB = iPB;
        this.iPC = iPC;
    }

    public void fillTriangle(Point3D[] points,V_RAM v_ram,int red,int green, int blue){

        Point ip1 = new Point((int)Math.round(points[iPA].x), ((int)Math.round(points[iPA].y)));
        Point ip2 = new Point((int)Math.round(points[iPB].x), ((int)Math.round(points[iPB].y)));
        Point ip3 = new Point((int)Math.round(points[iPC].x), ((int)Math.round(points[iPC].y)));

        //search minMax in Y
        int minY = Math.min(ip1.y, Math.min(ip2.y, ip3.y));
        int maxY = Math.max(ip1.y, Math.max(ip2.y, ip3.y));

        //allocate array
        MinMaxInX[] data = new MinMaxInX[maxY - minY + 1];
        for (int i = 0; i < data.length; i++) {
            data[i] = new MinMaxInX(ip1.x);

        }

        Cv02_Line.insertPointFromLineToMinMax(data, ip1, ip2, minY);
        Cv02_Line.insertPointFromLineToMinMax(data, ip1, ip3, minY);
        Cv02_Line.insertPointFromLineToMinMax(data, ip2, ip3, minY);
        //fill
        for (int y = 0; y < data.length; y++) {

            for (int x =  data[y].minX; x <=  data[y].maxX ; x++) {
                v_ram.setPixel(x, y + minY, red, green, blue);

            }
        }

    }

    public void drawTriangle(Point3D[] points,V_RAM v_ram,int red,int green, int blue){
        //Cv02_Line.drawLine(v_ram,(int)Math.round(points[iPA].x),(int)Math.round(points[iPA].y),(int)Math.round(points[iPB].x),(int)Math.round(points[iPB].y),red,green,blue);
        //Cv02_Line.drawLine(v_ram,(int)Math.round(points[iPB].x),(int)Math.round(points[iPB].y),(int)Math.round(points[iPC].x),(int)Math.round(points[iPC].y),red,green,blue);
        //Cv02_Line.drawLine(v_ram,(int)Math.round(points[iPC].x),(int)Math.round(points[iPC].y),(int)Math.round(points[iPA].x),(int)Math.round(points[iPA].y),red,green,blue);
    }

    public Point3D ComputeNormalVector(Point3D[] points){
            Point3D a =new Point3D(points[iPB].x-points[iPA].x,points[iPB].y-points[iPA].y,points[iPB].z-points[iPA].z);
            Point3D b = new Point3D(points[iPC].x-points[iPA].x,points[iPC].y-points[iPA].y,points[iPC].z-points[iPA].z);

            Point3D ret= new Point3D((a.y*b.z-a.z*b.y),(a.z*b.x-a.x*b.z),(a.x+b.y-a.y*b.x));
            return ret;
                }
}
