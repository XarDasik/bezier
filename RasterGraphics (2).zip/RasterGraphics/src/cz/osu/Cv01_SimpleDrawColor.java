package cz.osu;

public class Cv01_SimpleDrawColor {

    public static void drawHorizontal(V_RAM v_ram, int x1, int x2, int y, int red, int green, int blue){

        for (int i = x1; i < x2; i++) {
            v_ram.setPixel(i, y, red, green, blue);
        }
    }

    public static void drawVertical(V_RAM v_ram, int y1, int y2, int x, int red, int green, int blue){

        for (int i = y1; i < y2; i++) {
            v_ram.setPixel(x, i, red, green, blue);
        }
    }
}
