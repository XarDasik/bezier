package cz.osu;

public class KU2_DataToModel {
}
