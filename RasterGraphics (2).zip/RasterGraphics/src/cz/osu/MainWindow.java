package cz.osu;

import cz.osu.KU1.KU1_BezierAsMSWord;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class MainWindow extends JPanel{

    private ImagePanel imagePanel;
    private JLabel infoLabel;

    private V_RAM vram;

    public MainWindow(){

        initialize();
        
        vram = new V_RAM(500, 500);

        Point p1 = new Point(50, 40);
        Point p2 = new Point(250, 240);
        Point p3 = new Point(400, 250);

        Point p0 = p1;
        Point p4 = p3;

        Point p1L = new Point(p1.x - (p2.x - p0.x)/6,p1.y - (p2.y - p0.y)/6);
        Point p1R = new Point(p1.x + (p2.x - p0.x)/6,p1.y + (p2.y - p0.y)/6);

        Point p2L = new Point(p2.x - (p3.x - p1.x) /6, p2.y - (p3.y -p1.y /6));
        Point p2R = new Point(p2.x + (p3.x - p1.x) /6, p2.y + (p3.y -p1.y /6));

        Point p3L = new Point(p3.x - (p4.x - p2.x) /6, p3.y - (p4.y - p2.y) /6);
        Point p3R = new Point(p3.x + (p4.x - p2.x) /6, p3.y + (p4.y - p2.y) /6);


        KU1_BezierAsMSWord.drawBezier(vram, p1, p1R, p2L, p2, 255,255,255, 100);
        KU1_BezierAsMSWord.drawBezier(vram, p2, p2R, p3L,p3, 255,255,255, 100);
        /*vram.setPixel(p1.x,p1.y, 255,255,255);
        vram.setPixel(p2.x,p2.y, 255,255,255);
        vram.setPixel(p3.x,p3.y, 255,255,255);*/

        imagePanel.setImage(vram.getImage());
    }

    private void initialize(){

        setLayout(null);
        setFocusable(true);
        requestFocusInWindow();

        imagePanel = new ImagePanel();
        imagePanel.setBounds(10,60, 970, 600);
        this.add(imagePanel);

        //open image
        JButton button = new JButton();
        button.setBounds(150,10,120,30);
        button.setText("Load Image");

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                openImage();
            }
        });
        this.add(button);

        //save image as PNG
        JButton button4 = new JButton();
        button4.setBounds(10,10,120,30);
        button4.setText("Save as PNG");
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveImageAsPNG();
            }
        });
        this.add(button4);

        JFrame frame = new JFrame("Raster Graphics");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(this);
        frame.setSize(1004, 705);
        frame.setResizable(false);
        frame.setVisible(true);
    }

    private void openImage(){

        String userDir = System.getProperty("user.home");
        JFileChooser fc = new JFileChooser(userDir +"/Desktop");
        fc.setDialogTitle("Load Image");

        if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {

            File file = fc.getSelectedFile();

            try {

                BufferedImage temp = ImageIO.read(file);

                if(temp != null){

                    imagePanel.setImage(temp);

                }else {

                    JOptionPane.showMessageDialog(null, "Unable to load image", "Open image: ", JOptionPane.ERROR_MESSAGE);
                }

            }catch (IOException e){

                e.printStackTrace();
            }
        }
    }

    private void saveImageAsPNG(){

        String userDir = System.getProperty("user.home");
        JFileChooser fc = new JFileChooser(userDir +"/Desktop");
        fc.setDialogTitle("Save Image as PNG");

        if (fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {

            File file = fc.getSelectedFile();

            String fname = file.getAbsolutePath();

            if(!fname.endsWith(".png") ) file = new File(fname + ".png");

            try {

                ImageIO.write(imagePanel.getImage(), "png", file);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {

        new MainWindow();
    }
}
