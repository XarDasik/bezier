package cz.osu;

public class Cv12_BlackWhite {
}
