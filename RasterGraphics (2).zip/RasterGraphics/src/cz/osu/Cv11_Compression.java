package cz.osu;

public class Cv11_Compression {
}
