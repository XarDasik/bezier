package cz.osu;

public class MinMaxInX {
    public int minX;
    public int maxX;

    public MinMaxInX(int initialValue) {
        this.minX = initialValue;
        this.maxX = initialValue;
    }
}
