package cz.osu;

import java.awt.*;
import java.util.ArrayList;

public class Cv03_Bezier {

    private static double qx0;
    private static double qx1;
    private static double qx2;
    private static double qx3;

    private static double qy0;
    private static double qy1;
    private static double qy2;
    private static double qy3;

    public static void drawBezier(V_RAM v_ram, ArrayList<Point> points){
        int tSteps= 10;
        recomputeQValues(points);

        Point startPoint = points.get(0);
        for (int i = 1; i <=tSteps; i++) {
            double t = i/(double)tSteps;
            Point p= getPointByT(t);
            //Cv02_Line.drawLine(v_ram,startPoint.x, startPoint.y, p.x,p.y,250,250,250);
            startPoint=p;
        }
    }

    public static Point getPointByT(double t){
        double tt = t*t;
        double ttt = tt*t;

        double x = qx0 + qx1 * t + qx2 * tt + qx3 * ttt;
        double y = qy0 + qy1 * t + qy2 * tt + qy3 * ttt;

        return new Point((int)x,(int)y);
    }

    public static void recomputeQValues(ArrayList<Point> points){
        qx0 = points.get(0).x;
        qx1 = 3 * (points.get(1).x - points.get(0).x);
        qx2 = 3 * (points.get(2).x - 2 * points.get(1).x + points.get(0).x);
        qx3 = points.get(3).x- 3 * points.get(2).x + 3 * points.get(1).x - points.get(0).x;

        qy0 = points.get(0).y;
        qy1 = 3 * (points.get(1).y - points.get(0).y);
        qy2 = 3 * (points.get(2).y - 2 * points.get(1).y + points.get(0).y);
        qy3 = points.get(3).y - 3 * points.get(2).y + 3 * points.get(1).y - points.get(0).y;

    }
}
