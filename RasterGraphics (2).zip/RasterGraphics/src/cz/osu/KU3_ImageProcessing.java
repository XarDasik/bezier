package cz.osu;

public class KU3_ImageProcessing {
}
